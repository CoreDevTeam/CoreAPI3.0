#include <iostream>
#include <Windows.h>
#include <string>
#include <fstream>
#include <conio.h>

#include "CoreAPI_DATA.h"



Data::Data()
{

}

void Data::Draw()
{
	std::cout << "Data was successfully drawn";
}