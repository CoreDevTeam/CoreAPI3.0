#pragma once

#include "CoreAPI_DEVICE.h"



	class Data : public Device
	{
	private :
		
	public :
		Data();
		void Draw();
	};


/*
#include <iostream>
#include <fstream>
#include <limits>

using std::istream;

istream& jump_to(istream& stream, const size_t& zeile, const size_t zeichen )
{
    stream.seekg(0, std::ios::beg);
    for(int a(0);a < zeile - 1;++a)
        stream.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    stream.ignore(zeichen);
    return stream;
}

int main()
{
    std::ifstream stream("Bla.txt");
    jump_to(stream, 5, 3);
    std::cout << static_cast<char>(stream.get()) << '\n';
}
*/