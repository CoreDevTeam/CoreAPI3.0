#include <iostream>
#include <Windows.h>
#include <string>
#include <fstream>
#include <conio.h>

#include "CoreAPI_DEVICE.h"
#include "CoreAPI_TEXTELEMENT.h"
#include "CoreAPI_DATA.h"



Device::Device()
{
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
}

void Device::SaveCursorPos(void)
{
	_CONSOLE_SCREEN_BUFFER_INFO info;
	GetConsoleScreenBufferInfo(hConsole,&info);
	CursorPos = info.dwCursorPosition;
}

void Device::GotoCursorPos(COORD coord)
{
	SetConsoleCursorPosition(hConsole,coord);
}