#pragma once

enum TEXT_ALIGN
{
	ALIGN_LEFT,
	ALIGN_CENTER,
	ALIGN_RIGHT,
	TITLE
};

enum MOUSE_BUTTON
{
	KEY_M_RIGHT,
	KEY_M_LEFT,
	KEY_M_MIDDLE
};

struct MenuItem
{
	const char *Caption;
	TEXT_ALIGN text_align;
	byte color;
};

	class Device
	{
	private :

	public : 
		//virtual void Draw() = 0;
		//static Device* Create();
		TEXT_ALIGN text_align;
		HANDLE hConsole;
		byte FontColor;
		byte BGColor;
		HANDLE hStdInput,hStdOutput,hEvent;                         //WAIT_ABANDONED   = 128
		INPUT_RECORD ir[128];                                       //WAIT_OBJECT_0    = 0
		DWORD nRead;                                                //WAIT_TIMEOUT     = 258
		COORD xy;
		UINT i;
		COORD CursorPos;

		Device();
		void SaveCursorPos(void);
		void GotoCursorPos(COORD coord);
		void clear();
	};
