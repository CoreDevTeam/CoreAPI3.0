#include <iostream>
#include <Windows.h>
#include <string>
#include <fstream>
#include <conio.h>

#include "CoreAPI_TEXTELEMENT.h"
#include "CoreAPI_DEVICE.h"
#include "CoreAPI_GUI.h"


TextElement::TextElement(void)
{
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	text_align = ALIGN_LEFT;
}

SMALL_RECT TextElement::GetRect()
{
	_CONSOLE_SCREEN_BUFFER_INFO info;
	GetConsoleScreenBufferInfo(hConsole,&info);
	return info.srWindow;
}

void TextElement::StringTextElement(std::string Text, bool visible)
{
	if(visible)
	{
		std::cout << Text << std::endl;
	}
	
}

void TextElement::StringTextElementCopyBackup(std::string Text, bool visible,std::string* textcopy)
{
	if(visible)
	{
		std::cout << Text << std::endl; 
	}
	else
	{
		textcopy = &Text; 
	}
}

void TextElement::Draw()
{
	std::cout << "Element was successfully drawn";
}

void TextElement::SetFontColor(byte Color)
{
	FontColor = Color;
}

void TextElement::SetBGColor(byte Color)
{
	BGColor = Color*0x10;
}

void TextElement::Write(char *Text)
{
	SetConsoleTextAttribute(hConsole,FontColor | BGColor);
	printf("%s",Text);
}

