#pragma once

#include "CoreAPI_DEVICE.h"
#include "CoreAPI_GUI.h"

	class TextElement : public Device
	{
	private :
		std::string Text;
		bool visible;
	public :
		SMALL_RECT GetRect();
		void Draw();
		TextElement();
		void StringTextElement(std::string Text, bool visible);
		void StringTextElementCopyBackup(std::string Text, bool visible,std::string* textcopy);

		void SetFontColor(byte Color);
		void SetBGColor(byte Color);
		void Write(char *Text);



	/*
	void :
	Write
	WriteOnCoord
	Write
	SetTextColor
	SetWhitespaceColor
	SetBackgroundColor
	Fill
	*/
};

