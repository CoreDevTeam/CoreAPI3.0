#include <iostream>
#include <Windows.h>
#include <string>
#include <fstream>
#include <conio.h>
#include <sstream> 
#include <stdio.h>
#include <ctime>

#include "CoreAPI.h"

using namespace std;
std::string itoa(int value, int base) {
	
		std::string buf;
	
		// check that the base if valid
		if (base < 2 || base > 16) return buf;

		enum { kMaxDigits = 35 };
		buf.reserve( kMaxDigits ); // Pre-allocate enough space.
	
		int quotient = value;
	
		// Translating number to string with base:
		do {
			buf += "0123456789abcdef"[ std::abs( quotient % base ) ];
			quotient /= base;
		} while ( quotient );
	
		// Append the negative sign
		if ( value < 0) buf += '-';
	
		std::reverse( buf.begin(), buf.end() );
		return buf;
	}

int main()
{
	core::MenuItem* m = new core::MenuItem[5];
	core::CoreAPI capi;
	capi.setScreenSize(1024,800,1024,800);
	
	/*std::cout << capi.add(10,4325) << std::endl;
	capi.Draw_costum_warning_msg("lol");*/
	srand((unsigned)time(0));
	

	int rr = 1337; 
	ostringstream Str;
    Str << rr;
    string ZahlAlsString(Str.str());
    cout << ZahlAlsString << endl; 


	m[0].color=COLOR_GREEN;
	//capi.DrawBox(0,0,12,18,COLOR_WHITE,2,m);

	srand((unsigned)time(0));
	int random_integer;
	int random_integera;
	int r;
	int ra;
	int w;


	capi.SetBGColor(COLOR_BLACK);
	while(true){
	//input = _getch();
	//if(input = 'a')
	//{
		rr = rand();
		
			m[0].Caption=ZahlAlsString.c_str();
		random_integer = (rand()%1000)+0;
		
		random_integera = (rand()%1000)+0;
		ra = (rand()%5)+1;
		
		r = (rand()%5)+1;
		w = (rand()%1000)+1;

		capi.DrawBox(random_integer,random_integera,ra,r,COLOR_GREEN,2,m);
			w = (rand()%5000)+1;
		Beep(w,r);
		
	//}
	}
	_getch();
	return 0;
}
 
