#include <iostream>
#include <conio.h>

#include "CoreAPI.h"

int main()
{
	core::CoreAPI* core = new core::CoreAPI(5,6,"Test Console with CoreAPI-Version 1.2.0.3 Win32 Build 3",false);
	int _size = 5;

	core->Draw_costum_info_msg("Welcome !...");
	Sleep(100);

	core->SetBGColor(core::color::COLOR_BLACK);
	core->SetFontColor(core::color::COLOR_WHITE);

	std::vector<core::MenuItem> test(_size);
	test[0].color=core::color::COLOR_GREY;
	test[0].Caption="Please select";
	test[0].text_align=core::TITLE;

	test[1].color=core::color::COLOR_GREY;
	test[1].Caption="(1)Open a window";
	test[2].color=core::color::COLOR_GREY;
	test[2].Caption="(2)LOL";
	test[3].color=core::color::COLOR_GREY;
	test[3].Caption="(3)NOT";
	test[4].color=core::color::COLOR_GREY;
	test[4].Caption="(4)Quit programm";


	_getch();
	core->DrawBoxVec(0,0,22,15,core::color::COLOR_WHITE,_size+1,test);

	COORD Mycoord;
	Mycoord.X=0;
	Mycoord.Y=17;
	core->GotoCursorPos(Mycoord);
	
	std::cout << "Ich denke das dies ein sch" << core::specialChar::oe << "nes Projekt ist und bleiben wird" << std::endl;
	_getch();
	delete core;
}
