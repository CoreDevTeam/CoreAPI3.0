#include "Easy File.h"

#include <iostream>
#include <string>
#include <vector>

#include <fstream>

FileManager::FileManager () {}

void FileManager::createFile ( iopath filename ) {
	std::fstream file(filename.c_str(),std::ios::out);
	if ( file ) {
	file << "";
	}
	else { std::cerr << "unable to open file" << std::endl;}
	file.close();
}

void FileManager::removeFile ( iopath filename ) {
	if( remove( filename.c_str() ) != 0 ) {
		std::cerr << "Error deleting file" << std::endl;
	}
}

void FileManager::renameFile (iopath filename,std::string newFileName ) {
	if( rename( filename.c_str(), newFileName.c_str() ) != 0 ) {
		std::cerr << "Error renameing file" << std::endl;
	}
}

void FileManager::readFile (iopath filename,std::vector<std::string>& file_content) {
	std::fstream file(filename.c_str(),std::ios::in);
	std::string file_line;

	if ( file ) {
	while ( std::getline(file,file_line) ) {
		file_content.push_back(file_line);
	}
	}
	else { std::cerr << "unable to open file" << std::endl;}
	file.close();
}

void FileManager::writeFile (iopath filename,std::vector<std::string> file_content) {
	std::fstream file(filename.c_str(),std::ios::out | std::ios::app);

	if ( file ) {
	for ( unsigned int i = 0; i < file_content.size(); i++ ) {
		file << file_content[i] << std::endl;
	}
	}
	else { std::cerr << "unable to open file" << std::endl;}
	file.close();
}

void FileManager::backupFile (iopath filename) {
	std::fstream file(filename.c_str(),std::ios::in);
	std::string backup_str;
	std::vector<std::string> backup_vec;

	if ( file ) {
		
		while( std::getline(file,backup_str) ) {
			backup_vec.push_back(backup_str);
		}
		file.close();

		std::fstream file2("backup_"+filename+".temp",std::ios::out);

		for ( int i = 0; i < backup_vec.size(); i++ ) {
			file2 << backup_vec[i] << std::endl;
		}
		file2.close();
	}
	else{ std::cerr << "Unable to open file" << std::endl; }
}