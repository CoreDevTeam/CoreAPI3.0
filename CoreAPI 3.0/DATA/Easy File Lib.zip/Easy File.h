#include <iostream>
#include <string>
#include <vector>

#include <fstream>

class FileManager {
private :
	typedef std::string iopath;
	iopath filename,file;

	std::vector<std::string> file_content;

public :
	
	FileManager();

	void createFile(iopath filename);
	void removeFile(iopath filename);
	void renameFile(iopath filename, std::string newFileName);

	void readFile(iopath filename,std::vector<std::string>& file_content);
	void writeFile(iopath filename,std::vector<std::string> file_content); //one Element of the vector counts as one new line in the file

	void openFile(iopath filename,std::ios_base::openmode Mode);

	void backupFile(iopath filename);
};